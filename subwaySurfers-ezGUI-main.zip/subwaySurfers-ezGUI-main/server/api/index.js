const app = require("../index");
module.exports = app;
